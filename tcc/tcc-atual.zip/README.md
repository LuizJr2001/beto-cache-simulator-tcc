# Projeto TCC - Modelo ABNT (abnTeX2)

Este projeto foi convertido do padrão SBC para o modelo ABNT usando a classe `abntex2`, conforme orientação de migração para modelo de artigo ABNT.

## Arquivos principais

- `main.tex`: artigo principal em ABNT/abnTeX2.
- `referencias.bib`: referências em BibTeX, com citações autor-data via `abntex2cite`.
- `figuras/`: pasta para inserir prints dos simuladores.
- `instrumentos/`: questionário e modelo de inspeção heurística.

## Compilação no Overleaf

Use `main.tex` como arquivo principal. A bibliografia deve ser compilada com BibTeX normalmente. O projeto usa:

```latex
\usepackage[alf]{abntex2cite}
\bibliography{referencias}
```

## Figuras

O texto já contém espaços reservados com `INSERIR IMAGEM`. Para substituir, salve a figura em `figuras/` e troque o bloco por:

```latex
\begin{figure}[htp]
    \centering
    \includegraphics[width=.85\textwidth]{figuras/nome-da-figura.pdf}
    \caption{Descrição da figura.}
    \label{fig:nome-da-figura}
\end{figure}
```

Preferencialmente, gere as figuras em PDF para preservar a resolução.
